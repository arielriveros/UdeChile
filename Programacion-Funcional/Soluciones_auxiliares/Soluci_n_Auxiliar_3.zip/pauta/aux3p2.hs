import Test.Hspec
import Test.QuickCheck
import Test.Hspec.Core.QuickCheck(modifyMaxSuccess)

fibonacci :: Int -> Int
fibonacci 0 = 1
fibonacci 1 = 1
fibonacci n
  | n < 0     = error "Invalid fibonacci number index"
  | otherwise = fibonacci (n - 1) + fibonacci (n - 2)

phi :: Float
phi = (1 + sqrt 5) / 2

-- Utility functions:

fibQuotient :: Int -> Float
-- Returns f(n+1)/f(n)
fibQuotient n = fromIntegral (fibonacci (n + 1)) / fromIntegral (fibonacci n)

difference :: Num a => a -> a -> a
difference a b = abs $ a - b

isEpsilonClose :: Float -> Float -> Float -> Bool
isEpsilonClose epsilon a b = difference a b < epsilon

-- Test

fibonacciTest :: Spec
fibonacciTest = describe "fib(n + 1) / fib(n)" $
  modifyMaxSuccess (const 10) $ do
  it "is 0.7 close to phi:" $
    property $ \n -> (n::Int) > 0 && n < 20 ==>
      difference phi (fibQuotient n) < 0.7
  it "is always closer to phi:" $
    property $ \n -> (n::Int) > 0 && n < 20 ==>
      difference phi (fibQuotient (n + 1)) <= difference phi (fibQuotient n)


main :: IO()
main = hspec
  fibonacciTest
