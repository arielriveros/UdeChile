import Data.Char
import Test.Hspec
import Test.QuickCheck

{-- Cambiar este valor para probar disintos bits para codificar --}
-- inicialmente partimos con 8 pero Quickcheck no será capáz de generar los casos necesarios.
-- Si usamos 32 bits, veremos que los test ahora sí pasan, ya que trivialmente todos los Char
-- están codificados en 32 bits.
bitsOfEncoding = 8

bin2int :: [Int] -> Int
bin2int [] = 0
bin2int (b:bs) = b + 2 * bin2int bs

int2bin :: Int -> [Int]
int2bin 0 = []
int2bin n = n `mod` 2 : int2bin (n `div` 2)

addPadding :: Int -> [Int] -> [Int]
addPadding p bs
  | length bs > p = error "Binary already too long"
  | length bs < p = addPadding p $ bs ++ [0]
  | otherwise     = bs

encode :: String -> [Int]
encode = concat . map (addPadding bitsOfEncoding . int2bin . ord)

chop :: Int -> [Int] -> [[Int]]
chop _ [] = []
chop p bs = take p bs : chop p (drop p bs)

decode :: [Int] -> String
decode = map (chr . bin2int) . chop bitsOfEncoding

channel :: [Int] -> [Int]
channel = id

transmit :: String -> String
transmit = decode . channel . encode

transmitTest :: Spec
transmitTest = describe "String transmition" $
  it "returns exactly the same string" $
    property $ \s -> all ((< 2 ^ bitsOfEncoding - 1) . ord) s ==>
      transmit (s::String) == s

reverseTest :: Spec
reverseTest = describe "Reversing a list" $
  it "and concatenating behaves well:" $
    property $ \xs ys -> reverse ((xs::[Int]) ++ (ys::[Int])) == reverse ys ++ reverse xs

main :: IO()
main = hspec $ do
  transmitTest
  reverseTest
