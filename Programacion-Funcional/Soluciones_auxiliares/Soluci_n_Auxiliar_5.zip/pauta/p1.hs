data Expr = Val Int | Add Expr Expr | Sub Expr Expr

eval :: Expr -> Int
eval (Val n)   = n
eval (Add l r) = eval l + eval r
eval (Sub l r) = eval l - eval r

data Op = PUSH Int | ADD | SUB deriving Show

type Code = [Op]

type Stack = [Int]

exec :: Code -> Stack -> Stack
exec []         s       = s
exec (PUSH v:c) s       = exec c (v:s)
exec (ADD:c)    (m:n:s) = exec c (m + n:s)
exec (SUB:c)    (m:n:s) = exec c (m - n:s)

comp :: Expr -> Code
comp (Val n)   = [PUSH n]
comp (Add x y) = comp y ++ comp x ++ [ADD]
comp (Sub x y) = comp y ++ comp x ++ [SUB]

-- exec (comp e) [] = [eval e]

foldExpr :: (b -> b -> b) -> (b -> b -> b) -> (Int -> b) -> Expr -> b
foldExpr _    _    valF (Val v)   = valF v
foldExpr subF addF valF (Add x y) = addF (foldExpr subF addF valF x) (foldExpr subF addF valF y)
foldExpr subF addF valF (Sub x y) = subF (foldExpr subF addF valF x) (foldExpr subF addF valF y)

eval' :: Expr -> Int
eval' = foldExpr (-) (+) id

comp' :: Expr -> Code
comp' = foldExpr (\cx cy -> cy ++ cx ++ [SUB]) (\cx cy -> cy ++ cx ++ [ADD]) (\n -> [PUSH n])
