import Test.Hspec
import Test.QuickCheck

-- Test

setsTest :: Spec
setsTest = describe "conjuntos" $
  it "La suma de un conjunto y su complemento son el universo" $
    property $ \xs -> length (xs::[Int]) == length (filter p xs) + length (filter (not . p) xs) where
  p  = (> 100)

main :: IO()
main = hspec
  setsTest
