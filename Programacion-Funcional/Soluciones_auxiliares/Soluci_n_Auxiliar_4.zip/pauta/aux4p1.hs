-- Versión antigua, usando recursión explícita
filterMe' :: (a -> Bool) -> [a] -> [a]
filterMe' _ [] = []
filterMe' p (x:xs) = if p x then x:filterMe' p xs else filterMe' p xs

filterMe :: (a -> Bool) -> [a] -> [a]
filterMe p = foldr (\x acc -> if p x then x:filterMe p acc else filterMe p acc) []
