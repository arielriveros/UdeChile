processR :: (a -> b) -> (a -> Bool) -> [a] -> [b]
processR f p [] = []
processR f p (x:xs)
  | p x       = f x:processR f p xs
  | otherwise = processR f p xs

processMF :: (a -> b) -> (a -> Bool) -> [a] -> [b]
processMF f p xs = map f (filter p xs)

processPF :: (a -> b) -> (a -> Bool) -> [a] -> [b]
processPF f p = map f . filter p
