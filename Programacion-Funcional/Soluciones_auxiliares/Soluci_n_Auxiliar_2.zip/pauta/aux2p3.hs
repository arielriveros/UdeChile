sumIntsBetween :: Int -> Int -> Int
sumIntsBetween a b
  | a > b = 0
  | otherwise = b + sumIntsBetween a (b-1)

db :: Int -> Int
db x = x + x

subDbBetween :: Int -> Int -> Int
subDbBetween a b
  | a > b = 0
  | otherwise = db b + subDbBetween a (b - 1)

highOrderSumBetween :: (Int -> Int) -> Int -> Int -> Int
highOrderSumBetween f a b
  | a > b = 0
  | otherwise = f b + highOrderSumBetween f a (b - 1)

hoSumDmBetween :: Int -> Int -> Int
hoSumDmBetween = highOrderSumBetween db

hoSumIntsBetween :: Int -> Int -> Int
hoSumIntsBetween = highOrderSumBetween id

higherOrderSequenceApplication :: (Int -> Int -> Int) -> (Int -> Int) -> Int -> Int -> Int -> Int
higherOrderSequenceApplication f1 f2 a b z
  | a > b = z
  | otherwise = f1 (f2 b) (higherOrderSequenceApplication f1 f2 a (b-1) z)

hoFactorial :: Int -> Int
hoFactorial b = higherOrderSequenceApplication (*) id 1 b 1
