uncurryMe :: (a -> b -> c) -> ((a, b) -> c)
uncurryMe f = \(x, y) -> f x y

-- Opciones:
-- uncurryMe f (x, y) = f x y
-- uncurryMe = \f -> \(x, y) = f x y
