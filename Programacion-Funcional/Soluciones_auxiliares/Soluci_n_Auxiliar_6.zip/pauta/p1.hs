zip :: [a] -> [b] -> [(a,b)]
zip (a:as) (b:bs) = (a,b) : zip as bs
zip _      _      = []


iterate :: (a -> a) -> a -> [a]
iterate f a = a : iterate f (f a)
