data Tree = Tree  { depth :: Int
                  , value :: Int
                  , lChild  :: Tree
                  , rChild :: Tree }

makeTree :: Int -> Tree
makeTree = makeTreeAux 0
  where
    makeTreeAux depth v = Tree  { depth = depth
                                , value = v
                                , lChild  = makeTreeAux (depth + 1) (2 * v + 1)
                                , rChild = makeTreeAux (depth + 1) (3 * v + 1) }

traverseNodes :: Tree -> [Tree]
traverseNodes tree = nodes where
  nodes     = tree : children
  children  = concatMap (\t -> [ lChild t, rChild t ]) nodes

-- t = makeTree 1
-- value <$> take 10 (traverseNodes t)

distance :: Int -> Int -> Maybe Int
distance x0 xf = distanceAux nodes where
  nodes = traverseNodes $ makeTree x0
  distanceAux (t:ts)
    | value t == xf    = Just $ depth t
    | value t > 4 * xf = Nothing
    | otherwise        = distanceAux ts
