safetailCE :: [a] -> [a]
safetailCE xs = if null xs then xs else tail xs

safetailGE :: [a] -> [a]
safetailGE xs -- Ojo que no hay '=' en esta linea
  | null xs = xs
  | otherwise = tail xs

safetailPM :: [a] -> [a]
safetailPM [] = []
safetailPM (_:xs) = xs
