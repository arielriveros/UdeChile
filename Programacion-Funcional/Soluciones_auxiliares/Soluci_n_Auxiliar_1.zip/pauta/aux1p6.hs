luhnDouble :: Int -> Int
luhnDouble n = if doubl > 9 then doubl - 9 else doubl
  where doubl = n * 2

luhn :: Int -> Int -> Int -> Int -> Bool
luhn d1 d2 d3 d4 = (luhnSum `mod` 10) == 0
  where l2 = luhnDouble d2
        l3 = luhnDouble d3
        l4 = luhnDouble d4
        luhnSum = l2 + l3 + l4
