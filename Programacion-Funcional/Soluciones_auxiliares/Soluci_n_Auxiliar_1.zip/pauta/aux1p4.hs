thirdHT :: [a] -> a
thirdHT xs = head (tail (tail xs))

thirdPM :: [a] -> a
thirdPM (_:_:x:_) = x
