#!/usr/bin/python3
# -*- coding: utf-8 -*-
# METADATA
import db

# END METADATA

medicos = db.Doctor()

medicos.create_archivoTable()
medicos.create_medicoTable()